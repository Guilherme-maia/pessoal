# Darwin

<img src = "darwin_image.png" alt="Darwin" style = "height:1px; width:1px;"/>

"Não é o mais forte que sobrevive, nem o mais inteligente, mas o que melhor se adapta às mudanças".

# Ideia

Em 2020 tínhamos a necessidade de construir modelos mais eficientes e com maior velocidade de implantação, para isso montamos um ambiente Python e começamos a montar o que chamamos hoje de Notebook Darwin. O Notebook Darwin conseguiu diminuir consideravelmente o tempo de construção de um modelo e além disso nos deixou mais livre para testar novos algoritmos que são amplamente utilizados no mercado.

De forma simplista o Darwin contempla os principais passos de construção de um modelo, construímos os módulos dado as necessidades encontradas durante o processo de modelagem no python e dai vem o nome da ferramenta, como nada é escrito em pedra na visão de modelagem ao longo do tempo vamos evoluindo a ferramenta, mudando e adaptando o que for necessário para construir modelos mais eficientes.

Atualmente estamos na versão 2.0 do darwin. 

# Algoritmos 

O aprendizado de máquina (ML) é o estudo de algoritmos de computador que podem melhorar automaticamente por meio da experiência e do uso de dados.  É visto como parte da inteligência artificial . Os algoritmos de aprendizado de máquina constroem um modelo baseado em dados de amostra, conhecidos como dados de treinamento , para fazer previsões ou decisões sem serem explicitamente programados para isso. Os algoritmos de aprendizado de máquina são usados em uma ampla variedade de aplicações, como em medicina, filtragem de e-mail, reconhecimento de fala e visão computacional, onde é difícil ou inviável desenvolver algoritmos convencionais para realizar as tarefas necessárias. 

Um subconjunto de aprendizado de máquina está intimamente relacionado à estatística computacional , que se concentra em fazer previsões usando computadores; mas nem todo aprendizado de máquina é aprendizado estatístico. O estudo da otimização matemática fornece métodos, teoria e domínios de aplicação para o campo de aprendizado de máquina. A mineração de dados é um campo de estudo relacionado, com foco na análise exploratória de dados por meio de aprendizado não supervisionado.  Algumas implementações de aprendizado de máquina usam dados e redes neurais de uma maneira que imita o funcionamento de um cérebro biológico. Em sua aplicação em problemas de negócios, o aprendizado de máquina também é conhecido como análise preditiva.

## Análise SUPERVISIONADA


### Regressão Logística (Tradicional)
A regressão logística é uma técnica estatística que tem como objetivo produzir, a partir de um conjunto de observações, um modelo que permita a predição de valores tomados por uma variável categórica, frequentemente binária, em função de uma ou mais variáveis independentes contínuas e/ou binárias. Nessa ótica estamos construindo um modelo que é puramente estatístico e muitas suposições sobre os dados precisam ser garantidas para que o modelo mantenha sua performance em novos dados.


### Regressão Logística (Lasso - L1)

O lasso, desenvolvido por Tibshirani (1996), faz ajustes no processo de estimação do modelo de Regressão Logística (tradicional), esse ajuste ajuda a diminuir as "limitações" do modelo. A regularização Lasso - também referida como L1 - aplica uma penalização equivalente ao valor absoluto da magnitude dos coeficientes. Colocando em palavras mais simples, a L1 vai aplicar uma restrição aos coeficientes menos importantes, levando-os a zero e também funcionando como uma técnica de seleção de atributos.


### Regressão Logística (Ridge)

Uma alternativa ao lasso (que na realidade é anterior a ele) desenvolvido por  Hoerl e Kennard (1970). Funciona de modo semelhando ao Lasso, porém aplicando uma penalização equivalente ao valor ao quadrado da magnitude dos coeficientes. O método Ridge, com o parâmetro lambda, penaliza os coeficientes que assumem valores muito grandes, levando-os a tender a zero. Deste modo, suaviza os coeficientes relacionados (multicolineares), os quais aumentam o ruído no modelo.

### Árvore 

Árvores de regressão consistem em uma metodologia não paramétrica que leva a resultados extremamente interpretáveis. Uma árvore é construída por particionamentos recursivos no espaço das covariáveis. Cada particionamento recebe o nome de nó e cada resultado final recebe o nome de folha;

### RandonForest

Uma característica interessante das árvores de regressão é que são extremamente interpretáveis. No entanto, costumam apresentar baixo poder preditivo quando comparadas aos demais estimadores. Bagging e florestas aleatórias (Breiman, 2001b) são métodos que contornam essa limitação combinando diversas árvores para fazer uma predição para um mesmo problema;


### Boosting

Assim como florestas aleatórias e o bagging, o boosting também consiste na agregação de diferentes estimadores da função de regressão. Contudo, esta combinação é feita de outra forma. Existem diversas variações e implementações de boosting. Abordaremos aqui a forma mais usual. No boosting, o estimador g(x) é construído incrementalmente. Inicialmente, atribuímos o valor de g(x) ≡ 0. Este estimador possui alto viés, mas baixa variância (a saber, zero). A cada passo, atualizaremos o valor de g de modo a diminuir o viés e aumentar a variância da nova função. Isto é feito adicionando-se a g uma função que prevê os resíduos ri = Yi − g(xi). Uma forma de se fazer isso é com a utilização de uma árvore de regressão. É importante que essa árvore tenha profundidade pequena de modo a evitar o super-ajuste. Além disso, ao invés de simplesmente adicionar essa função por completo, adicionamos ela multiplicada por λ (chamado de learning rate), um fator entre 0 e 1 que tem por finalidade evitar o super-ajuste;

Alguns algoritmos baseados em boosting mais utilizados:

> GradienteBoosting

> Xgboost

> LigthGBM

> AdaBoost

### SVM
Uma máquina de vetores de suporte (SVM, do inglês: support-vector machine) é um conceito na ciência da computação para um conjunto de métodos de aprendizado supervisionado que analisam os dados e reconhecem padrões, usado para classificação e análise de regressão. O SVM padrão toma como entrada um conjunto de dados e prediz, para cada entrada dada, qual de duas possíveis classes a entrada faz parte, o que faz do SVM um classificador linear binário não probabilístico. 

### PCA - Analise de Componentes Principais

A Análise de Componentes Principais (ACP) ou Principal Component Analysis (PCA) é um procedimento matemático que utiliza uma transformação ortogonal (ortogonalização de vetores) para converter um conjunto de observações de variáveis possivelmente correlacionadas num conjunto de valores de variáveis linearmente não correlacionadas chamadas de componentes principais. O número de componentes principais é sempre menor ou igual ao número de variáveis originais. Os componentes principais são garantidamente independentes apenas se os dados forem normalmente distribuídos (conjuntamente).

### Kernel PCA (KPCA)

O Kernel PCA (KPCA) é uma versão não-linear da Análise de Componentes Principais. Esse método é calculado implicitamente através de uma função Kernel para um espaço de maior dimensionalidade. O KPCA é capaz de extrair características não lineares a partir de um conjunto de dados (Schölkopf, Knirsch, et al., 1998).

## Análise Não Supervisionada 

### K-Médias

Em estatística, agrupamento k-means é um método de segregar em torno de centros (centroides) diversos dados, criando o que analogamente na química chamamos de clustering que gera o efeito de particionar n observações dentre k grupos onde cada observação pertence ao grupo mais próximo da média. Isso resulta em uma divisão do espaço de dados em um Diagrama de Voronoi.

### Métodos Hierárquicos
Os métodos hierárquicos da análise de cluster tem como principal característica um algoritmo capaz de fornecer mais de um tipo de partição dos dados. Ele gera vários agrupamentos possíveis, onde um cluster pode ser mesclado a outro em determinado passo do algoritmo.

Esses métodos não exigem que já se tenha um número inicial de clusters e são considerados inflexíveis uma vez que não se pode trocar um elemento de grupo. Eles podem ser classificados em dois tipos: Aglomerativos e Divisivos.

# Desenvolvedor

Guilherme Ribeiro Maia | drt: 929001538 | email: guilherme_ribeiro_maia@carrefour.com