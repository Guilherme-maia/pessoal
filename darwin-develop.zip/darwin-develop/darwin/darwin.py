#####################################
# Pacotes
import subprocess
import os
import time
import random

#Manipulação de dataframes
import pandas as pd
from pandas import Series
import pandas.core.algorithms as algos

#Gravação do objeto final para implantação
import pickle
import re
import traceback
import string

#Pacotes para deixar mais dimanico o jupyter
from IPython import display
from IPython.display import display, Markdown, clear_output
import ipywidgets as widgets
#import plotly.graph_objects as go #install chart_studio
import plotly.graph_objs as go
import plotly.io as pio
import plotly.express as px
from ipywidgets import interact, interact_manual
import cufflinks as cf
cf.go_offline(connected=True)
cf.set_config_file(colorscale='plotly', world_readable=True)
pio.renderers.default = "notebook_connected"
import plotly.offline as py

#tratamentos de dataframes
from sklearn.model_selection import train_test_split

#Funções matematicas
import numpy as np
import scipy.stats.stats as stats

#Pacotes dos modelos
import lightgbm as lgb 
import xgboost as xgb 
from xgboost import plot_importance
from sklearn.tree import DecisionTreeClassifier
from sklearn.ensemble import AdaBoostClassifier
from sklearn.model_selection import GridSearchCV
from sklearn import linear_model
from sklearn.linear_model import LogisticRegression
from sklearn.svm import SVC
from sklearn.ensemble import RandomForestClassifier
from sklearn.ensemble import GradientBoostingClassifier
from sklearn.linear_model import LassoCV
from sklearn.linear_model import Lasso
from sklearn.ensemble import ExtraTreesClassifier
from sklearn import ensemble
from scipy.stats import chi2_contingency
from sklearn import tree
from sklearn.linear_model import LinearRegression
from sklearn.metrics import r2_score
import statsmodels.api as sm 
import statsmodels.formula.api as smf


import sklearn.metrics as metrics
import matplotlib.pyplot as plt
from datetime import datetime
from sklearn.metrics import accuracy_score
from sklearn.metrics import roc_curve, auc
from scipy.stats import ks_2samp
from scipy import stats
import seaborn as sns
sns.set()

import shap

import sklearn #for building models

from numpy import loadtxt
from matplotlib import pyplot as plt
from matplotlib.colors import ListedColormap

##https://www.kaggle.com/miklgr500/catboost-with-gridsearch-cv
from catboost import CatBoostClassifier
from catboost import Pool
from catboost import CatBoost

# Feature engine e PipeLine
from sklearn.pipeline import Pipeline

from sklearn.preprocessing import StandardScaler
from sklearn.preprocessing import MinMaxScaler

from feature_engine.encoding import OneHotEncoder
from feature_engine.imputation import ArbitraryNumberImputer
from feature_engine.imputation import CategoricalImputer
from feature_engine.encoding import MeanEncoder
from feature_engine.wrappers import SklearnTransformerWrapper


# importando os pacotes necessários
from sklearn.cluster import KMeans
from mpl_toolkits.mplot3d import Axes3D
from sklearn.metrics import silhouette_score, silhouette_samples

from sklearn.decomposition import PCA

from IPython.core.display import HTML
HTML("""
<style>
.output_png {
    display: table-cell;
    text-align: center;
    vertical-align: middle;
}
</style>
""")

from IPython.display import display, HTML
CSS = """.output {align-items: center;}"""
HTML('<style>{}</style>'.format(CSS))

    
########################################################


class Darwin():

    def arruma_cep(cep):
        return str(cep).zfill(8)

    def linearity_plot(self, data, variavel, target,bins = 10):

        """
        Função que plotar um grafico de dispersão com a variavel categorizada no eixo X, e a média de target no eixo Y.
        Utilizada para avaliar de forma observacional a elegibilidade de linearidade de uma variavel sob a otica de uma regressão linear.
        
        Parâmetros:
            data (pd.DataFrame): DataFrame com os dados.
            variavel (str): Nome da coluna para o eixo X.
            target (str): Nome da coluna para o eixo Y.
        """

        data = data.copy()
        # Verificar se a variável resposta está no DataFrame
        if target not in data.columns:
            raise ValueError(f"Variável target '{target}' não encontrada no DataFrame.")
            
        # Verificar se a variável está no DataFrame
        if variavel not in data.columns:
            raise ValueError(f"Variável '{variavel}' não encontrada no DataFrame.")
        
        # Categorizar a variável em faixas
        data[f"{variavel}_binned"], bins_used = pd.qcut(data[variavel], q = bins, retbins = True, duplicates = 'drop')
        
        # Converter os bins para números inteiros
        data[f"{variavel}_binned"] = data[f"{variavel}_binned"].cat.codes
        
        # Ajustar a regressão linear
        data_aux = data.groupby([f"{variavel}_binned"])[target].mean().reset_index()
        
        X = data_aux[[f"{variavel}_binned"]]
        y = data_aux[target]
        model = LinearRegression()
        model.fit(X, y)
        y_pred = model.predict(X)
        
        # Plotar os dados originais
        plt.scatter(X, y, color = "blue", label = "Dados Reais")
        plt.plot(X, y_pred, color = "black", label = "Reta Ajustada")
        
        # Adicionar título, rótulos e legenda
        plt.title("Teste de Linearidade")
        plt.xlabel(variavel)
        plt.ylabel('% Target')
        plt.legend()
        plt.show();

    def categorization_by_tree(self
                            , dados = None
                            , name_data = 'dados'
                            , coluns_numerics = None
                            , index_df = None
                            , target = None
                            , max_depth = 4
                            , ccp_alpha = 0.001
                            , print_rules = False
                            , file_name = 'categorizacao_modelo_xpto.txt'):

        
        """
        Algoritimo de categorização de variaveis com base em uma resposta binaria baseada em arvore.
        
        Parâmetros:
        - dados (pd.DataFrame): DataFrame com os dados.
        - name_data (str): Nome dos dados a serem incluidos no codigo de saida (nome deve ser igual ao nome do obsejto dados porem em string)
        - coluns_numerics (list): Lista das variaveis numericas a serem categorizadas pela função
        - index_df (list): Lista de variaveis a serem consideradas como index para não serem categorizadas
        - target (str): Nome da coluna que será alvo na categorização binaria
        - max_depth (int): Máximo de profundidade que a arvore sera gerada
        - ccp_alpha (float) : Parametro de poda da arvore. A ideia é evidar overfit
        - print_rules (bollean): Indicador se deseja que as regras sejam printadas em tela
        - file_name (str): Nome/caminho do arquivo que sera salvo as regras
        
        Saída:
        - Código pronto para copiar e colar, aplicável no pandas.
        """
        
        # Setando os indexs a nao serem categorizados
        if index_df == None:
            pass
        else:
            dados = dados.set_index(index_df)
        
        # Ajuste de Missing
        dados = dados.fillna(0)
        
        # Criando arquivo em Branco
        with open(file_name,"w") as arquivo:
            pass
        
        # Escrevendo respostas da categorização
        if print_rules == True:
            print('#################################')
            
        with open(file_name,'a') as arquivo:
            print('#################################',file = arquivo)
        
        for v in coluns_numerics:
        
            if v == target:
                pass
            else:
                ####################
                # CRIANDO A ARVORE #
                ####################
                clf = tree.DecisionTreeClassifier(
                                                  criterion = 'gini'
                                                , max_depth = max_depth
                                                , ccp_alpha = ccp_alpha
                                                , splitter = 'best'
                                                , min_samples_leaf = 0.05
                                                )

                clf = clf.fit(dados[[v]], dados[[target]])

                ################################
                # ORDENANDO A SAIDA DAS REGRAS #
                ################################
                unique_values = list(dict.fromkeys(clf.tree_.threshold.tolist()))
                unique_values.sort(reverse = True)
                unique_values.pop(-1)
                unique_values.sort(reverse = False)

                ##############################
                # VERIFICACAO SE TEVE QUEBRA #
                ##############################
                if len(unique_values) < 1:
                    pass
                else:
                    ######################################
                    # FAZENDO LOOP NO VETOR DE VARIAVEIS #
                    ######################################
                    for i in range(0,len(unique_values)):
                        categorias = list(range(0,len(unique_values)))
                        if i == 0:
                            if print_rules == True:
                                print(name_data+"['cat_"+str(v)+"'] = np.where("+name_data+"['"+v+"'].isnull(), 'C_NULL',")

                            with open(file_name,'a') as arquivo:
                                print(name_data+"['cat_"+str(v)+"'] = np.where("+name_data+"['"+v+"'].isnull(), 'C_NULL',",file=arquivo)

                        if print_rules == True:
                            print("np.where("+name_data+"['"+v+"'] <= "+str(unique_values[i])+", 'C"+str(categorias[i])+"',")

                        with open(file_name,'a') as arquivo:
                            print("np.where("+name_data+"['"+v+"'] <= "+str(unique_values[i])+", 'C"+str(categorias[i])+"',",file=arquivo)

                    parenteses = ')'
                    fecha_where = (len(unique_values)+1)*parenteses

                    if print_rules == True:
                        print("'C99'" + fecha_where)
                        print('#################################')

                    with open(file_name,'a') as arquivo:
                            print("'C99'" + fecha_where,file = arquivo)
                            print('#################################',file = arquivo)

        

    def apply_rules(self
                    , dados = None
                    , file_name = 'categorizacao_modelo_xpto.txt'):

        #####################
        # ABRINDO O ARQUIVO #
        #####################                
        with open(file_name,'r') as arquivo:
            codigo = arquivo.read()       
        
        ########################################################
        # BUSCANDO NOME DA TABELA DO ARQUIVO PARA SUBSTITUICAO #
        ########################################################
        result = self.find_word_between_chars(codigo, start_char = '#\n', end_char = '[')
        codigo = codigo.replace(result[0],'dados')

        ########################
        # EXECUTANDO O ARQUIVO #
        ########################
        exec(codigo)
            
        return dados


    def stability_features(self
                        , dados = None
                        , coluns_numerics = None
                        , target = 'target'
                        , data_version = 'data_version'
                        , figsize = [10,5]):
        
        from matplotlib.colors import ListedColormap
        plt.style.use('ggplot')
        
        #Ajustes
        dados = dados.copy()
        dados.reset_index(inplace = True) 
        dados['values_for_graph'] = 1 
        dados['data_version'] = dados['data_version'].str[:10]
        
        for variavel in coluns_numerics:
            
            if variavel == 'cat_'+target:
                pass
            else:
                ############################
                # Estabilidade dado volume #
                ############################
                cubo = dados.groupby([data_version,variavel])['values_for_graph'].sum().reset_index()
                fig = pd.pivot_table(cubo
                                    , index = [data_version]
                                    , values = ["values_for_graph"]
                                    , columns = [variavel]
                                    , aggfunc = np.sum)\
                        .apply(lambda x: x*100/sum(x), axis = 1)\
                        .plot(kind = "bar", stacked = True, figsize = (figsize[0],figsize[1]))

                plt.legend(loc = 'center left', bbox_to_anchor = (1, .5), ncol = 1, fontsize = 8, title_fontsize = 10)
                plt.title('Evolução da Categoria '+variavel,fontdict = {'fontsize' : 10})
                plt.xlabel("Data_version", fontsize = 10) 
                plt.ylabel("%", fontsize = 10)
                plt.show();

                ##########################
                # Estabilidade dado alvo #
                ##########################
                cubo_alvo = dados.groupby([data_version,variavel])[target].sum().reset_index()
                cubo_total = dados.groupby([data_version,variavel])['values_for_graph'].sum().reset_index()
                cubo = pd.concat([cubo_alvo,cubo_total['values_for_graph']], axis = 1)
                cubo['%target'] = cubo[target]/cubo['values_for_graph']

                plt.figure(figsize=(figsize[0],figsize[1]))
                sns.lineplot(data = cubo, x = data_version, y = '%target', hue = variavel, marker = 'o')
                plt.xticks(rotation=90)
                plt.legend(loc = 'center left', bbox_to_anchor = (1, .5), ncol = 1, fontsize = 8, title_fontsize = 10)
                plt.title('Evolução da %Taxa por Categoria '+variavel,fontdict = {'fontsize' : 10})
                plt.xlabel("Data_version", fontsize = 10) 
                plt.ylabel("%", fontsize = 10)
                plt.show();


    def cramers_v(self, var1, var2):
        """
        Calcula a correlação de Cramér's V entre duas variáveis categóricas.
        """

        tabela_contingencia = pd.crosstab(var1, var2)
        chi2, _, _, _ = chi2_contingency(tabela_contingencia)
        n = tabela_contingencia.sum().sum()
        r, k = tabela_contingencia.shape
        return np.sqrt((chi2 / n) / min(k - 1, r - 1))

    def cramers_v_df(self,df):
        """
        Calcula a matriz de correlação de Cramér's V para todas as variáveis categóricas de um DataFrame.
        """
        
        # Selecionar apenas colunas categóricas
        colunas_categoricas = df.select_dtypes(include = ["object", "category"]).columns
            
        # Filtrar colunas com pelo menos 2 categorias
        colunas_validas = [col for col in colunas_categoricas if df[col].nunique() > 1]

        # Criar uma matriz vazia para as colunas válidas
        matriz_corr = pd.DataFrame(index = colunas_validas, columns = colunas_validas)

        # Calcular Cramér's V para cada par de variáveis categóricas
        for col1 in colunas_validas:
            for col2 in colunas_validas:
                # Correlação de uma variável com ela mesma
                if col1 == col2:
                    matriz_corr.loc[col1, col2] = 1.0  
                else:
                    matriz_corr.loc[col1, col2] = self.cramers_v(df[col1], df[col2])

        return matriz_corr.astype(float)

    def calculate_iv(self, data, target):

        """
        Calcula o Information Value (IV) de todas as variáveis de um DataFrame em relação ao target binário.
        
        Parâmetros:
            data (pd.DataFrame): DataFrame contendo as variáveis independentes e a variável target.
            target (str): Nome da coluna target binária (0 ou 1).
        
        Retorna:
            pd.DataFrame: DataFrame com o IV de cada variável.
        """

        iv_list = []

        for col in data.columns:
            if col == target:
                continue
            
            # Verificar tipo da variável
            if data[col].dtype == 'object' or data[col].nunique() < 20:
                bins = data[col]
            else:
                bins = pd.qcut(data[col], q = 10, duplicates = 'drop')  
            
            # Criar tabela de frequência
            tabela = pd.crosstab(bins, data[target], normalize = 'columns')
            tabela.columns = ['% Bad', '% Good']
            
            # Prevenir divisão por zero ou logaritmos inválidos
            tabela['% Bad'] = tabela['% Bad'].replace(0, 0.01)   # Substitui 0 por um valor muito pequeno
            tabela['% Good'] = tabela['% Good'].replace(0, 0.01) # Substitui 0 por um valor muito pequeno
            
            # Calcular o WOE
            tabela['WOE'] = np.log(tabela['% Good'] / tabela['% Bad'])
            
            # Calcular o IV
            tabela['IV'] = (tabela['% Good'] - tabela['% Bad']) * tabela['WOE']
            iv = tabela['IV'].sum()
            
            # Adicionar o resultado na lista
            iv_list.append({'Variable': col, 'IV': iv})
        
        # Retornar um DataFrame com os resultados
        return pd.DataFrame(iv_list).sort_values(by='IV', ascending=False)


    def select_variables(self, data, target, iv_threshold=0.03, corr_threshold=0.7):
        """
        Seleciona variáveis com base no Information Value (IV) e na correlação de Cramér-V.
        
        Parâmetros:
            data (pd.DataFrame): DataFrame contendo as variáveis independentes e a variável target.
            target (str): Nome da variável target binária (0 ou 1).
            iv_threshold (float): Limite mínimo de IV para considerar uma variável elegível.
            corr_threshold (float): Limite máximo para considerar variáveis correlacionadas.

        Retorna:
            list: Lista de variáveis elegíveis.
        """

        # Calcular o IV de todas as variáveis
        iv_results = self.calculate_iv(data, target)
        iv_results = iv_results[iv_results['IV'] > iv_threshold]
        
        # Criar matriz de correlação de Cramér-V para variáveis com IV > iv_threshold
        selected_vars = iv_results['Variable'].tolist()
        cramers_matrix = pd.DataFrame(index=selected_vars, columns=selected_vars, dtype=float)
        
        for var1 in selected_vars:
            for var2 in selected_vars:
                if var1 == var2:
                    cramers_matrix.loc[var1, var2] = 1.0
                elif pd.isnull(cramers_matrix.loc[var1, var2]):
                    cramers_matrix.loc[var1, var2] = self.cramers_v(data[var1], data[var2])
                    cramers_matrix.loc[var2, var1] = cramers_matrix.loc[var1, var2]

        # Filtrar variáveis correlacionadas
        eligible_vars = set(selected_vars)
        for var1 in selected_vars:
            for var2 in selected_vars:
                if var1 != var2 and cramers_matrix.loc[var1, var2] > corr_threshold:
                    # Manter a variável com maior IV
                    iv1 = iv_results.loc[iv_results['Variable'] == var1, 'IV'].values[0]
                    iv2 = iv_results.loc[iv_results['Variable'] == var2, 'IV'].values[0]
                    if iv1 > iv2:
                        eligible_vars.discard(var2)
                    else:
                        eligible_vars.discard(var1)

        return list(eligible_vars)


    def linearity(self, data, target, threshold = 0.75, bins = 10):
        
        """
        Realiza regressões lineares para cada variável contínua do DataFrame,
        categorizando as variáveis em faixas e retorna um DataFrame das variáveis
        ordenadas pelo R^2 observado.
        
        Parâmetros:
            data (pd.DataFrame): DataFrame contendo as variáveis contínuas e a variável resposta binária.
            target (str): Nome da variável resposta (0 ou 1).
            bins (int): Número máximo de faixas para categorizar as variáveis contínuas.

        Retorna:
            pd.DataFrame: DataFrame contendo as variáveis contínuas e seus respectivos R^2, ordenados em ordem decrescente.
        """
        
        # Verificar se a variável resposta está no DataFrame
        if target not in data.columns:
            raise ValueError(f"Variável target '{target}' não encontrada no DataFrame.")
        
        # Inicializar lista para armazenar resultados
        results = []
        
        # Separar variáveis contínuas
        continuous_vars = data.select_dtypes(include = [np.number]).columns.drop(target)
        
        # Iterar sobre cada variável contínua
        for var in continuous_vars:
            try:
                # Categorizar a variável em faixas
                data[f"{var}_binned"], bins_used = pd.qcut(data[var], q = bins, retbins = True, duplicates = 'drop')
                
                # Converter os bins para números inteiros
                data[f"{var}_binned"] = data[f"{var}_binned"].cat.codes
                
                # Ajustar a regressão linear
                data_aux = data.groupby([f"{var}_binned"])[target].mean().reset_index()
                
                X = data_aux[[f"{var}_binned"]]
                y = data_aux[target]
                model = LinearRegression()
                model.fit(X, y)
                
                # Prever e calcular o R^2
                y_pred = model.predict(X)
                r2 = r2_score(y, y_pred)
                
                # Salvar o resultado
                results.append({'Variable': var, 'R2': r2})
                
                # Remover a coluna de bins para evitar problemas em iterações futuras
                data.drop(columns = [f"{var}_binned"], inplace=True)
                
            except Exception as e:
                print(f"Erro ao processar a variável '{var}'")
        
        # Converter os resultados em DataFrame e ordenar pelo R^2 em ordem decrescente
        results_df = pd.DataFrame(results).sort_values(by = 'R2', ascending = False).reset_index(drop = True)
        
        results_df['Test_Linear'] = np.where(results_df['R2'] >= threshold, "Yes", "No")
        
        return results_df


    def find_word_between_chars(self, text, start_char, end_char):
        """
        Encontra uma palavra dentro de um texto, limitada entre dois caracteres.
        
        Parâmetros:
            text (str): O texto onde será feita a busca.
            start_char (str): O caractere inicial do intervalo.
            end_char (str): O caractere final do intervalo.
            word (str): A palavra a ser encontrada.

        Retorna:
            list: Todas as ocorrências da palavra encontrada no intervalo.
        """
        # Construir o padrão da expressão regular
        pattern = fr'{re.escape(start_char)}(.*?){re.escape(end_char)}'
        
        # Encontrar todas as ocorrências
        matches = re.findall(pattern, text)
        
        return matches

    ################################################################################################################
        
    # VERIFICA DE DUMMIE
    def se_dummy(self, base,var):
        """
        Verifica de uma variavel é dummy
        """
        a = base[var] == 1
        b = base[var] == 0
        return ((a.sum()+b.sum()) == base.shape[0])
    
    ########################################################
    
    #Boxplot
    def boxplot(self, base_input, y_variavel, categorias = None, dimensao = [8,6]):
    
        sns.set(rc={'figure.figsize':(dimensao[0],dimensao[1])})
    
        if (categorias == None):
            ax = sns.boxplot(y = y_variavel, data = base_input)
            ax.tick_params(labelsize=9)
            plt.show()

        else:
            ax = sns.boxplot(x = categorias,y = y_variavel, data = base_input)
            ax.tick_params(labelsize = 9)
            plt.show()

    ########################################################
            
    # ANALISE UNIVARIADA
    def univariada(self, metadados, base, perc_corte):
   
        n = base.shape[0]
        vet_max_variabilidade = []
        vet_nomes = []
        vet_fl_variabilidade = []
        n_vars = base.shape[1]

        for i in range(0,n_vars):
            clear_output(wait = True)
            display(self.progresso_barra(value = i , value_min = 1, value_max = n_vars - 1, step = 1))
        
            nome_variavel  = base.columns[i]
            a = base.groupby(nome_variavel)[nome_variavel].count()
            a = a/n
            vet_nomes.append(nome_variavel)
            vet_max_variabilidade.append(np.max(a))

        df_c = pd.DataFrame({'Variaveis': vet_nomes,'varibilidade_uni': vet_max_variabilidade})
        df_c['fl_elegivel_uni'] = np.where(df_c.varibilidade_uni.isnull(), 0,
                                  np.where(df_c.varibilidade_uni > perc_corte, 0,1))
    
        return df_c.sort_values(['varibilidade_uni'],ascending=0)
    
    ########################################################
    # ANALISE DE INFORMATION VALUE
    def calculo_IV(self, base, conceito, min_iv, quebras):
    
        global vet_Iv
        n = base.shape[0]
        vet_Iv = []
        vet_IV_valor = []
        n_vars = base.shape[1]
   
        for i in range(0,n_vars):
            clear_output(wait = True)
            display(self.progresso_barra(value = i , value_min = 1, value_max = n_vars - 1, step = 1))
        
            nome_variavel  = base.columns[i]
        
            if (nome_variavel != conceito):
                a = self.inf_value(base,conceito,nome_variavel,quebras)
                vet_Iv.append(nome_variavel)
                vet_IV_valor.append(a[1])

        df_iv = pd.DataFrame({'Variaveis': vet_Iv,'Information_value': vet_IV_valor})
        df_iv['fl_elegivel_iv'] = np.where(df_iv.Information_value > min_iv, 1, 0)
        
        return df_iv.sort_values(['Information_value'],ascending=0)
    
        
    def inf_value(self, base,conceito,variavel,quebras):
    
        # Verifica se variável é contínua
        if ((base[variavel].dtypes in ['int64','int32','float32','float64'])) and (self.se_dummy(base,variavel) == False):
                
            # Valores de bons e maus
            bons = base[conceito] == 0
            maus = base[conceito] == 1

            # Quebra da variável desejada
            categorias = pd.qcut(base[variavel],quebras,duplicates='drop')
        
            # Contagem de bons e maus por categoria
            tab_bons = pd.crosstab(categorias, columns='#', aggfunc='sum', dropna=False, values=bons)
            tab_maus = pd.crosstab(categorias, columns='#', aggfunc='sum', dropna=False, values=maus)

            # Montagem das variáveis
            tabela_final = pd.DataFrame({'Bons':tab_bons['#']/tab_bons['#'].sum(),
                                         'Maus':tab_maus['#']/tab_maus['#'].sum()})
            #Truncamento
            tabela_final['Bons']=tabela_final['Bons'].replace(0, 0.0001)
            tabela_final['Maus']=tabela_final['Maus'].replace(0, 0.0001)
            tabela_final['PD'] = tab_maus['#'] / (tab_bons['#'] + tab_maus['#'])
            tabela_final['ODDS'] = (tab_bons['#']/tab_bons['#'].sum())/(tab_maus['#']/tab_maus['#'].sum())
            tabela_final['WoE'] = np.log(tabela_final['Bons']/tabela_final['Maus'])
            tabela_final['IV Parcial'] = (tabela_final['Bons'] - tabela_final['Maus'])*tabela_final['WoE'] 
            #Calculo do IV
            IV = tabela_final['IV Parcial'].sum()
    
        else:
               
            # Valores de bons e maus
            bons = base[conceito] == 0
            maus = base[conceito] == 1
    
            # Contagem de bons e maus por categoria
            tab_bons = pd.crosstab(base[variavel], columns='#', aggfunc='sum', dropna=False, values=bons)
            tab_maus = pd.crosstab(base[variavel], columns='#', aggfunc='sum', dropna=False, values=maus)
    
            # Montagem das variáveis
            tabela_final = pd.DataFrame({'Bons':tab_bons['#']/tab_bons['#'].sum(),
                                         'Maus':tab_maus['#']/tab_maus['#'].sum()})
            #Truncamento        
            tabela_final['Bons']=tabela_final['Bons'].replace(0, 0.0001)
            tabela_final['Maus']=tabela_final['Maus'].replace(0, 0.0001)
            tabela_final['ODDS'] = (tab_bons['#']/tab_bons['#'].sum())/(tab_maus['#']/tab_maus['#'].sum())
            tabela_final['PD'] = tab_maus['#'] / (tab_bons['#'] + tab_maus['#'])
            tabela_final['WoE'] = np.log(tabela_final['Bons']/tabela_final['Maus'])
            tabela_final['IV Parcial'] = (tabela_final['Bons'] - tabela_final['Maus'])*tabela_final['WoE'] 
            #Calculo do IV
            IV = tabela_final['IV Parcial'].sum()
         
        if((tabela_final.shape[0] == 1) and (base[variavel].value_counts().shape[0] <= 2)):
            # Valores de bons e maus
            bons = base[conceito] == 0
            maus = base[conceito] == 1

            # Contagem de bons e maus por categoria
            tab_bons = pd.crosstab(base[variavel], columns='#', aggfunc='sum', dropna=False, values=bons)
            tab_maus = pd.crosstab(base[variavel], columns='#', aggfunc='sum', dropna=False, values=maus)
    
            # Montagem das variáveis
            tabela_final = pd.DataFrame({'Bons':tab_bons['#']/tab_bons['#'].sum(),
                                         'Maus':tab_maus['#']/tab_maus['#'].sum()})
            #Truncamento
            tabela_final['Bons']=tabela_final['Bons'].replace(0, 0.0001)
            tabela_final['Maus']=tabela_final['Maus'].replace(0, 0.0001)
            tabela_final['ODDS'] = (tab_bons['#']/tab_bons['#'].sum())/(tab_maus['#']/tab_maus['#'].sum())
            tabela_final['PD'] = tab_maus['#'] / (tab_bons['#'] + tab_maus['#'])
            tabela_final['WoE'] = np.log(tabela_final['Bons']/tabela_final['Maus'])
            tabela_final['IV Parcial'] = (tabela_final['Bons'] - tabela_final['Maus'])*tabela_final['WoE'] 
    
            #Calculo do IV
            IV = tabela_final['IV Parcial'].sum()
        
        return tabela_final,IV
    
    ########################################################
    
    # AJUSTE DE METADADOS  
    def ajuste_metadados(self, dataframe): 
        
        train = dataframe
        t = []
        
        for i in train.columns:
            t.append(train[i].dtypes)
        
        n = []
        for i in train.columns:
            n.append(i)
        
        aux_t = pd.DataFrame(data = t, columns = ["Tipos"])
        aux_n = pd.DataFrame(data = n, columns = ["Variaveis"])
        df_tipovars = pd.concat([aux_t, aux_n.reindex(columns=aux_t.columns)])
        data = []
        
        for f in train.columns:
            # Definindo o papel das variáveis:
            if f == 'target':
                role = 'target'
            elif f == 'id':
                role = 'id'
            elif f == 'cpf_cnpj':
                role = 'id'
            elif f == 'num_numberx':
                role = 'id'
            elif f == 'num_serno':
                role = 'id'
            else:
                role = 'input'

            # Definindo o tipo das variáveis: nominal, ordinal, binary ou interval
            if f == 'target':
                level = 'binary'
            if train[f].dtypes == 'object' or f == 'id' or f == 'cpf_cnpj' or f == 'num_serno' or f == 'num_numberx': 
                level = 'nominal'
            elif train[f].dtypes in ['float','float64','float32','Float64','Float32']:
                level = 'interval'
            elif train[f].dtypes in ['int','int64','int32','Int64','Int32']:
                level = 'ordinal'

            # Todas variáveis são incializadas com keep exceto o id e safra
            keep = True
            if f == 'id':
                keep = False
            if f == 'data_version':
                keep = False
            if f == 'cd_posicao':
                keep = False
            if f == 'cpf_cnpj':
                keep = False
            if f == 'num_numberx':
                keep = False
            if f == 'num_serno':
                keep = False

            # Definindo o tipo das variáveis da tabela de entrada
            dtype = train[f].dtypes

            # Criando a lista com todo metadados
            f_dict = {'Variaveis': f, 'Role': role, 'Level': level, 'Keep': keep, 'Tipo': dtype}
            data.append(f_dict)
    
        meta = pd.DataFrame(data, columns = ['Variaveis', 'Role', 'Level', 'Keep', 'Tipo'])

        # Quantidade de domínios distintos para cada cariável do tipo ordinal e nominal
        card = []

        v = train.columns
        for f in v:
            dist_values = train[f].value_counts().shape[0]
            qtd_missing = train[f].isnull().sum()
            f_dict = {'Variaveis': f, 'Cardinality': dist_values, 'Qtd_Missing': qtd_missing}
            card.append(f_dict)

        card = pd.DataFrame(card, columns = ['Variaveis', 'Cardinality','Qtd_Missing'])
        metadados_train = pd.merge(meta, card, on = 'Variaveis')
        
        return metadados_train

    
    #################################################           
    
    # DESCRITIVA UNIVARIADA
    def descritiva_table(self, dataframe, metadados, dir_resultados, plots = True, dimensao = [8,5]):
    
        plt.style.use('ggplot')
        sns.set(rc={'figure.figsize':(dimensao[0],dimensao[1])})
    
        resumo_num = []
        resumo_cat = []
    
        #Detectando os tipos dos dados
        dados_cat = list(metadados[(metadados.Level  == 'nominal') &
                                   (metadados.Role == 'input') & 
                                   (metadados.Keep == True)]['Variaveis'])
    
        print("Número de variáveis categóricas: ", len(dados_cat))

        dados_num = list(metadados[((metadados.Level  == 'ordinal')|(metadados.Level == 'interval')) & 
                                      (metadados.Role == 'input') & (metadados.Keep == True)]['Variaveis'])  

        print("Número de variáveis contínuas: ", len(dados_num))
    
        #Selecionando as variaveis
        tab_categoricas = dataframe[dados_cat]
        tab_numericas = dataframe[dados_num]

        if len(dados_num) > 0:
            resumo_num = pd.DataFrame({'qtd': tab_numericas.shape[0],
                                       'qtd_missing': tab_numericas.isnull().sum(),
                                       'taxa_missing': tab_numericas.isnull().sum()/tab_numericas.shape[0],
                                       'desvio': tab_numericas.std(),
                                       'minimo': tab_numericas.min(),
                                       'quantil_01': tab_numericas.quantile(q = 0.01).T,
                                       'quantil_10': tab_numericas.quantile(q = 0.10).T,
                                       'quantil_25': tab_numericas.quantile(q = 0.25).T,
                                       'mediana': tab_numericas.median(),
                                       'media': tab_numericas.mean(),
                                       'quantil_75': tab_numericas.quantile(q = 0.75).T,
                                       'quantil_90': tab_numericas.quantile(q = 0.90).T,
                                       'quantil_99': tab_numericas.quantile(q = 0.99).T,
                                       'maximo': tab_numericas.max()
                                    })
        
            if plots == True:
                for col in tab_numericas.columns.values:
                    nome_da_figura = dir_resultados + "/Boxplot_" + col 
                    grafico = sns.boxplot(y = col, data = tab_numericas)
                    plt.savefig(nome_da_figura)
                    plt.show();
        
        if len(dados_cat) > 0:
        
            resumo_cat = pd.DataFrame({'qtd': tab_categoricas.shape[0],
                                       'qtd_missing': tab_categoricas.isnull().sum(),
                                       'taxa_missing': tab_categoricas.isnull().sum()/tab_numericas.shape[0],
                                       'cardinalidade': tab_categoricas.nunique()
                                      })
        
            tab_categoricas = tab_categoricas.fillna('missing')
            
            if plots == True:
                for col in tab_categoricas.columns.values:
                    aa = pd.DataFrame(tab_categoricas.groupby(tab_categoricas[col]).agg({col:[np.size]}))
                    bb = pd.DataFrame({col: list(sorted(tab_categoricas[col].unique())),
                                      'qtd_total': list(aa[(col, 'size')])})
                    bb['distribuição'] = bb.qtd_total/sum(bb.qtd_total)
                    
                    grafico = sns.barplot(y = col, x = "distribuição", palette = sns.color_palette("Blues_d") , data=bb)
                    nome_da_figura = dir_resultados + "/Barras_" + col
                    plt.savefig(nome_da_figura)
                    plt.show();

        return resumo_num, resumo_cat
    
    #################################################         
     
    def descritiva_univariada(self, tabela_1, variavel_categorica = 'safra', variavel_target = "target", plot = True, ylim = [0,1]):
    
        tabela_1 = tabela_1.fillna(-999)
    
        aa = pd.DataFrame(tabela_1.groupby(tabela_1[variavel_categorica]).agg({variavel_target: [np.size, np.sum]}))
    
        bb = pd.DataFrame({'faixas': list(sorted(tabela_1[variavel_categorica].unique())),
                           'qtd_total': list(aa[(variavel_target, 'size')]),
                           'qtd_target_1': list(aa[(variavel_target, 'sum')])})

        bb['distribuição'] = bb.qtd_total/sum(bb.qtd_total)
        bb['taxa_target_1_linha'] = (bb['qtd_target_1']/bb['qtd_total'])

        if plot == True:
            grafico = sns.catplot(x='faixas', y='taxa_target_1_linha', kind='point', data=bb, color = color_csf['vermelho_hex'])
            plt.ylim(ylim[0], ylim[1])
            plt.xticks(rotation=90)

            grafico = sns.barplot(x = 'faixas', y = 'distribuição', data=bb , color = color_csf['principal_hex'])
            for p in grafico.patches:
                grafico.annotate(format(p.get_height(), '.2f'), (p.get_x() + p.get_width() / 2., 
                                 p.get_height()), ha = 'center', va = 'center', xytext = (0, 10), 
                                 textcoords = 'offset points')
        
            plt.title('Distribuição vs Target')
            plt.ylabel('Distribuição')
            plt.xlabel(variavel_categorica)
            return pd.DataFrame(bb), grafico;
        else:
            return pd.DataFrame(bb)
    
    #################################################   
    
    def calculate_vif(self, features,valor_se_missing = -99, limite_vif = 10):
    
        features[np.isnan(features)] = valor_se_missing 
        
        vif = pd.DataFrame()
        vif["Variaveis"] = features.columns
        vif["vif"] = [variance_inflation_factor(features.values, i) for i in range(features.shape[1])]    
        vif['fl_elegivel_vif'] = np.where(vif.vif <= limite_vif, 1, 0)
        
        return(vif)
    
        
    #################################################
    
    def ks_roc_gini(self, dataframe,conceito,score,plot = True, dimensao = [5,4]):
        
        n_good = dataframe[dataframe[conceito] == 0]
        n_bad  = dataframe[dataframe[conceito] == 1]

        # Cálculo de KS
        ks = stats.ks_2samp(n_good[score],n_bad[score])[0]*100
    
        #Cálculo de Roc
        fpr, tpr, threshold = metrics.roc_curve(dataframe[conceito], dataframe[score])
        roc = 100*auc(fpr, tpr)
        gini = 100*(2*roc/100 - 1)
    
        estatisticas = {'ks': ks,'roc': roc,'gini': gini}

        if plot == True:
            plt.style.use('ggplot')
            plt.figure(figsize=(dimensao[0],dimensao[1]))
            lw = 2
            plt.plot(fpr, tpr, color='blue',lw=lw, label='Roc (%0.0f)' % roc)
            plt.plot(fpr, tpr, color='blue',lw=lw, label='Gini (%0.0f)' % gini)
            plt.plot(fpr, tpr, color='blue',lw=lw, label='Ks (%0.0f)' % ks)
            plt.plot([0, 1], [0, 1], color='navy', lw=lw, linestyle='--')
            plt.xlim([0.0, 1.0])
            plt.ylim([0.0, 1.05])
            plt.xlabel('Falso Positivo', fontsize=12)
            plt.ylabel('Verdadeiro Positivo', fontsize=12)
            plt.legend(loc="lower right")
            plt.legend(fontsize=12) 
            plt.title('Curva ROC - Data Science', fontsize=12)
            plt.show()
        return estatisticas
    
    #################################################    
    
    def ks_roc_gini_safra(self, dataframe,conceito,score,safra,plot=True):
    
        filtros_safra = dataframe[safra].unique()
        filtros_safra.sort()
        ks_calculados = []
        roc_calculados = []
        gini_calculados = []
        qtd_calculado = []
        taxa_target = []
        
        for i in filtros_safra:
        
            #Filtrando a base com a safra de referência
            df_new = dataframe.loc[(dataframe[safra] == i)]
                
            #Calculo de KS
            n_good = df_new[(df_new[conceito] == 0)]
            n_bad  = df_new[(df_new[conceito] == 1)]
            ks = stats.ks_2samp(n_good[score],n_bad[score])[0]*100
    
            #Cálculo de Roc e Gini
            fpr, tpr, threshold = metrics.roc_curve(df_new[conceito], df_new[score])
            roc = 100*auc(fpr, tpr)
            gini = 100*(2*roc/100 - 1)
    
            taxa_target.append(100*(df_new[(df_new[conceito] == 1)].shape[0]/df_new.shape[0]))
            qtd_calculado.append(df_new.shape[0])
            ks_calculados.append(ks)
            roc_calculados.append(roc)
            gini_calculados.append(gini)
    
        estatisticas = pd.DataFrame({'Safra': filtros_safra,
                                     #'Safra': (str(w) for w in filtros_safra),
                                     'Qtd': qtd_calculado, 
                                     'Taxa_1': taxa_target,
                                     'Ks': ks_calculados,
                                     'Roc': roc_calculados,
                                     'Gini': gini_calculados})
    
        if plot == True:
            plt.style.use('ggplot')
            plt.figure(figsize = (7,4))
            lw = 2
            plt.plot(estatisticas['Safra'], estatisticas['Ks'], lw = lw, color = 'blue')
            plt.ylim([0, 100])
            plt.xlabel('Safras', fontsize = 15)
            plt.ylabel('KS', fontsize = 15)
            plt.title('Data Science - KS', fontsize = 18)
            plt.show()
    
            plt.style.use('ggplot')
            plt.figure(figsize = (7,4))
            lw = 2
            plt.plot(estatisticas['Safra'], estatisticas['Roc'], lw=lw, color='blue')
            plt.ylim([40, 100])
            plt.xlabel('Safras', fontsize=15)
            plt.ylabel('Roc', fontsize=15)
            plt.title('Data Science - Roc', fontsize = 18)
            plt.show()
        
            plt.style.use('ggplot')
            plt.figure(figsize = (7,4))
            lw = 2
            plt.plot(estatisticas['Safra'], estatisticas['Gini'], lw=lw, color='blue')
            plt.ylim([0, 100])
            plt.xlabel('Safras', fontsize=15)
            plt.ylabel('Gini', fontsize=15)
            plt.title('Data Science  - Gini', fontsize = 18)
            plt.show()
        
        return estatisticas

    #################################################   
    
    def ks_roc_gini_train_test(self, dataframe1,dataframe2,conceito,score, plot = True ,dimensao=[5,4]):
     
        n_good_train = dataframe1[dataframe1[conceito] == 0]
        n_bad_train = dataframe1[dataframe1[conceito] == 1]
    
        n_good_teste = dataframe2[dataframe2[conceito] == 0]
        n_bad_teste  = dataframe2[dataframe2[conceito] == 1]

        # Cálculo de KS
        ks_treino = stats.ks_2samp(n_good_train[score],n_bad_train[score])[0]*100
        ks_teste = stats.ks_2samp(n_good_teste[score],n_bad_teste[score])[0]*100
    
        #Cálculo de Roc
        fpr_treino, tpr_treino, threshold = metrics.roc_curve(dataframe1[conceito], dataframe1[score])
        fpr_teste, tpr_teste, threshold = metrics.roc_curve(dataframe2[conceito], dataframe2[score])
    
        roc_treino = 100*auc(fpr_treino, tpr_treino)
        gini_treino = 100*(2*roc_treino/100 - 1)
    
        roc_teste = 100*auc(fpr_teste, tpr_teste)
        gini_test = 100*(2*roc_teste/100 - 1)
    
        estatisticas = {'ks_treino': ks_treino,
                        'ks_teste': ks_teste,
                        'roc_treino': roc_treino,
                        'roc_teste': roc_teste,
                        'gini_treino': gini_treino,
                        'gini_teste': gini_test}
    
        if plot == True:
            plt.style.use('ggplot')
            plt.figure(figsize=(dimensao[0],dimensao[1]))

            plt.plot(fpr_treino, tpr_treino, color='blue',lw=2, label='Roc (Treino = %0.0f)' % roc_treino)
            plt.plot(fpr_teste, tpr_teste, color='darkorange',lw=2, label='Roc (Teste = %0.0f)' % roc_teste)

            plt.plot([0, 1], [0, 1], color='navy', lw=2, linestyle='--')
            plt.xlim([0.0, 1.0])
            plt.ylim([0.0, 1.05])
            plt.xlabel('Falso Positivo', fontsize=12)
            plt.ylabel('Verdadeiro Positivo', fontsize=12)
            plt.legend(loc="lower right")
            plt.legend(fontsize=12) 
            plt.title('Curva ROC - Data Science', fontsize=12)
            plt.show()
   
        return estatisticas

    def ks_roc_gini_train_test_oot(self, dataframe1, dataframe2, dataframe3, conceito, score, plot = True ,dimensao=[5,4]):
     
        n_good_train = dataframe1[dataframe1[conceito] == 0]
        n_bad_train = dataframe1[dataframe1[conceito] == 1]
    
        n_good_teste = dataframe2[dataframe2[conceito] == 0]
        n_bad_teste  = dataframe2[dataframe2[conceito] == 1]

        n_good_oot = dataframe3[dataframe3[conceito] == 0]
        n_bad_oot  = dataframe3[dataframe3[conceito] == 1]
        
        # Cálculo de KS
        ks_treino = stats.ks_2samp(n_good_train[score],n_bad_train[score])[0]*100
        ks_teste = stats.ks_2samp(n_good_teste[score],n_bad_teste[score])[0]*100
        ks_oot = stats.ks_2samp(n_good_oot[score],n_bad_oot[score])[0]*100
    
        #Cálculo de Roc
        fpr_treino, tpr_treino, threshold = metrics.roc_curve(dataframe1[conceito], dataframe1[score])
        fpr_teste, tpr_teste, threshold = metrics.roc_curve(dataframe2[conceito], dataframe2[score])
        fpr_oot, tpr_oot, threshold = metrics.roc_curve(dataframe3[conceito], dataframe3[score]) 

        roc_treino = 100*auc(fpr_treino, tpr_treino)
        gini_treino = 100*(2*roc_treino/100 - 1)
    
        roc_teste = 100*auc(fpr_teste, tpr_teste)
        gini_test = 100*(2*roc_teste/100 - 1)
      
        roc_oot = 100*auc(fpr_oot, tpr_oot)
        gini_oot = 100*(2*roc_oot/100 - 1)
    
        estatisticas = {'ks_treino': ks_treino,     'ks_teste': ks_teste,    'ks_oot': ks_oot,
                        'roc_treino': roc_treino,   'roc_teste': roc_teste,  'roc_oot': roc_oot,
                        'gini_treino': gini_treino, 'gini_teste': gini_test, 'gini_oot': gini_oot}
    
        if plot == True:
            plt.style.use('ggplot')
            plt.figure(figsize=(dimensao[0],dimensao[1]))

            plt.plot(fpr_treino, tpr_treino, color='blue',lw=2, label='Roc (Treino = %0.0f)' % roc_treino)
            plt.plot(fpr_teste, tpr_teste, color='darkorange',lw=2, label='Roc (Teste = %0.0f)' % roc_teste)
            plt.plot(fpr_oot, tpr_oot, color='black',lw=2, label='Roc (Teste = %0.0f)' % roc_oot)

            plt.plot([0, 1], [0, 1], color='navy', lw=2, linestyle='--')
            plt.xlim([0.0, 1.0])
            plt.ylim([0.0, 1.05])
            plt.xlabel('Falso Positivo', fontsize = 12)
            plt.ylabel('Verdadeiro Positivo', fontsize = 12)
            plt.legend(loc = "lower right")
            plt.legend(fontsize = 12) 
            plt.title('Curva ROC - Data Science', fontsize = 12)
            plt.show()
   
        return estatisticas

    #################################################   

    def lift(self, tabela_a,variavel_categorica = "fx_score", rounds = 3):

        aa = pd.DataFrame(tabela_a.groupby(tabela_a[variavel_categorica]).agg({'target': [np.size, np.sum]}))
    
        bb = pd.DataFrame({'faixas': list(sorted(tabela_a[variavel_categorica].unique())),
                           'qtd_total': list(aa[('target', 'size')]),
                           'qtd_target_1': list(aa[('target', 'sum')])
                          })

        bb = bb.sort_values(by='faixas', ascending=False)

        bb['distribuição'] = bb.qtd_total/sum(bb.qtd_total)
        bb['taxa_target_1_linha'] = bb['qtd_target_1']/bb['qtd_total']
        bb['taxa_target_1_coluna'] = (bb['qtd_target_1'] / sum(bb.qtd_target_1))
        bb['acu_taxa_target_1_coluna'] = np.cumsum(bb.taxa_target_1_coluna).round(rounds)
    
        grafico = sns.lineplot(x="faixas", y="acu_taxa_target_1_coluna", data=bb , color="r") 
        for i,j in zip(bb.faixas,bb.acu_taxa_target_1_coluna):
            grafico.annotate(str(j),xy=(i,j),ha = 'center', va = 'center', xytext = (0, 5), 
                             textcoords = 'offset points')
        
        grafico = sns.barplot(x='faixas', y='distribuição', data=bb , color = color_csf['principal_hex'])
        for p in grafico.patches:
            grafico.annotate(format(p.get_height(), '.2f'), (p.get_x() + p.get_width() / 2., 
                             p.get_height()), ha = 'center', va = 'center', 
                             xytext = (0, 10), textcoords = 'offset points')
            grafico.grid(True)
            grafico.set_xlim(max(bb.faixas)+0.5, min(bb.faixas)-0.5)  # decreasing time
            plt.title('Lift: Score x Acu.Target')
            plt.ylabel('Distribuição Score')
            plt.xlabel('Faixas')
            
        return bb, grafico
    
    #################################################      
      
    def ks1_categorico(self, table_1, table_2, variavel, variavel_tempo = "safra",rounds = 3):
    
        aa = pd.DataFrame({'quebras': list(sorted(table_1[variavel].unique())),
                           'qdt_esperada': list(table_1.groupby([variavel]).size())})
        aa['dist_esperada'] = aa['qdt_esperada']/table_1.shape[0]           
                   
        bb = pd.DataFrame({'quebras': list(sorted(table_2[variavel].unique())),
                           'qdt_observada': list(table_2.groupby([variavel]).size())})
        bb['dist_observada'] = bb['qdt_observada']/table_2.shape[0]   
    
        resumo_aa_bb = pd.concat([aa, bb], axis=1)
        resumo_aa_bb['ks1_parcial'] = abs(resumo_aa_bb['dist_esperada'] - resumo_aa_bb['dist_observada'])
    
        return round(max(resumo_aa_bb['ks1_parcial']),rounds)
    
    #################################################       
    
    def psi_categorico(self, table_1, table_2, variavel, variavel_tempo = "safra", rounds = 3):
    
        aa = pd.DataFrame({'quebras': list(sorted(table_1[variavel].unique())),
                           'qdt_esperada': list(table_1.groupby([variavel]).size())})
        aa['dist_esperada'] = aa['qdt_esperada']/table_1.shape[0]           
                   
        bb = pd.DataFrame({'quebras': list(sorted(table_2[variavel].unique())),
                           'qdt_observada': list(table_2.groupby([variavel]).size())})
        bb['dist_observada'] = bb['qdt_observada']/table_2.shape[0]   
    
        resumo_aa_bb = pd.concat([aa, bb], axis=1)
    
        resumo_aa_bb['psi_parcial'] = np.log(resumo_aa_bb['dist_observada']/resumo_aa_bb['dist_esperada'])*(resumo_aa_bb['dist_observada']-resumo_aa_bb['dist_esperada'])
    
        return round(sum(list(resumo_aa_bb.psi_parcial)),rounds)


    #################################################     
    def psi_table(self, table_1,table_2,n_quebras = 10):
    
        psi = []
        vet_var = []
        n_vars = table_1.shape[1]
    
        for i in range(0,n_vars):
            psi.append(calculate_psi(table_1[table_1.columns[i]], 
                                     table_2[table_2.columns[i]], 
                                     buckettype = 'quantiles', 
                                     buckets = n_quebras, 
                                     axis = 0))
        
            vet_var.append(table_1.columns[i])
    
        resumo = pd.DataFrame({'Variaveis': vet_var,'psi': psi})
    
        resumo["alerta"] = np.where(resumo.psi <= 0.1, "Verde",
                           np.where(resumo.psi <= 0.25, "Amarelo","Vermelho"))
                               
    
        return resumo

    
    ##################################################################
    # MODELAGEM
    ##################################################################
    
    def alinhamento_de_score(self, resposta, prob_0, valor_central = 500, dobra_odds = 100, score_minimo = 1,seed = 1234):
        
        modelo =  LogisticRegression(penalty = 'l2', C = 1,
                                     dual = False, tol = 0.0001, 
                                     fit_intercept = True, 
                                     intercept_scaling = 1, 
                                     max_iter = 1000, 
                                     multi_class = 'ovr').fit(prob_0, resposta)
        
        prob_0['xbeta'] = modelo.intercept_[0] + modelo.coef_[0][0] * prob_0['prob_0']
        prob_0['prescore'] = (valor_central + (prob_0['xbeta']*dobra_odds)/np.log(2))
        prescore_min = prob_0['prescore'].min()
        prescore_max = prob_0['prescore'].max()
        prob_0['SCORE_ALINHADO'] = (score_minimo + 
                    ((prob_0['prescore'] - (prescore_min))*(1000-score_minimo))/(prescore_max - prescore_min)).astype(int)
        
        print("=======================")
        print("Fórmula de Alinhamento")
        print("=======================")
        
        print("")
        print("df['XBETA'] = ", modelo.intercept_[0] ,"+",modelo.coef_[0][0]," * df['prob_0']")
        print("df['PRESCORE'] = (",valor_central,"+ (df['XBETA']*",dobra_odds,")/np.log(2))")
        print("PRESCORE_MIN = ",prescore_min)
        print("PRESCORE_MAX = ",prescore_max)
        print("VALOR_MINIMO = ",score_minimo)
        print("df['SCORE_FINAL'] = (VALOR_MINIMO + ((df['PRESCORE'] - (PRESCORE_MIN))*(1000-VALOR_MINIMO))/(PRESCORE_MAX - PRESCORE_MIN)).astype(int)")   
        
        return pd.concat([prob_0,resposta],axis=1)
    
    ############################################    

    def plot_impacto_logistico(self, modelo, colunas_xtrain, cores = 'atc', axis_plot = [7,7]):
    
        all_coefs = list(modelo.coef_[0])
        all_coefs.append(modelo.intercept_[0])
        variaveis = list(colunas_xtrain)
        variaveis.append('intercepto')

        df_plot = pd.DataFrame({'Variaveis': variaveis, 'Coef': all_coefs, 'Coef_abs': np.abs(all_coefs)})
       
        if cores == 'atc':
            df_plot['Cores'] = np.where(df_plot['Coef'] > 0,'#0A7C43','#F86302')     
        
        else:
            df_plot['Cores'] = np.where(df_plot['Coef'] > 0,'#075DA7','#1BAFE6')

        g = df_plot.sort_values(by = ['Coef_abs'],ascending=False)
    
        f, ax = plt.subplots(figsize = (axis_plot[0], axis_plot[1]))
        sns.set_theme(style = "darkgrid")
        sns.barplot(x = g['Coef'], y = g['Variaveis'],palette = g['Cores'])
        ax.set_xlabel("Impacto da Variavel")
        ax.set_title("Coeficientes das Variáveis - Modelo Logístico");    
    
    ############################################ 
    
    def evolucao_no_tempo_v1(self, base_ref,base_oot,safra = "safra", quantidade = 8):
        
        plt.style.use('ggplot')

        def cut_n(dataframe, quantidade):
            bins = []
            df = dataframe.select_dtypes('number')
            for col in df.columns:
                bins_aux = algos.quantile(df[col], np.linspace(0, 1, quantidade))
                bins.append(bins_aux)
            return pd.DataFrame(bins, index = df.columns).T

        def apply_cut(dataframe, tab_bins):
            
            df = dataframe.select_dtypes('number')
            dataframe_final = df.drop(df.columns,axis = 1)
            
            for col in df.columns:
                nome = "fx_"+col
                d1 = pd.DataFrame({nome : pd.cut(df[col], np.unique(tab_bins[col]), include_lowest = False)})
                d1[nome] = d1[nome].astype("category")
                dataframe_final = pd.concat([dataframe_final, d1] , axis = 1)
            
            return dataframe_final

        tab_bins = cut_n(base_ref.drop([safra], axis = 1), quantidade)
        tabela = pd.concat([base_ref,base_oot],axis = 0, sort = False)
        dados_cat = apply_cut(tabela.drop([safra], axis = 1), tab_bins)

        dados_cat = pd.concat([dados_cat, tabela[safra].astype(str)],axis = 1)
        dados_cat['value'] = 1
        dados_cat[safra] = dados_cat[safra].astype("category")

        for f in dados_cat.columns.values:
            if dados_cat[f].nunique() >= 1:
                if ((f != 'value') & (f != safra)):
                    nome = f+'.png'
                    dados_cat[f] = dados_cat[f].astype("category")

                    fig = pd.pivot_table(dados_cat, index = [safra], values = ["value"], columns = [f], aggfunc = np.sum)\
                            .apply(lambda x: x*100/sum(x), axis = 1)\
                            .plot(kind = "bar", stacked = True, figsize = (14,6),
                                  colormap = ListedColormap(sns.color_palette("husl", quantidade)))

                    plt.legend(loc = 'center left', bbox_to_anchor = (1, .5), ncol = 1, fontsize = 8, title_fontsize = 10)
                    plt.title(f,fontdict = {'fontsize' : 12})
                    plt.xlabel("Safras", fontsize = 12) 
                    plt.ylabel("Percentage (%)", fontsize = 12)
                    plt.show();
                    

    def evolucao_no_tempo(self, base_ref, base_oot, safra = "safra", quantidade = 10):
                
        def cut_n(dataframe, quantidade):
            bins = []
            df = dataframe.select_dtypes('number')
            for col in df.columns:
                if self.se_dummy(df,col):
                    bins_aux = [df[col].unique()[0],df[col].unique()[1]] * (5)
                    bins_aux.sort()
                    bins.append(bins_aux)
                else: 
                    #bins_aux = algos.quantile(df[col], np.linspace(0, 1, quantidade))
                    bins_aux = pd.qcut(df[col], q = quantidade, retbins = False, duplicates = 'drop')
                    bins.append(bins_aux)
            return pd.DataFrame(bins, index = df.columns).T

        def apply_cut(dataframe, tab_bins):
            
            df = dataframe.select_dtypes('number')
            dataframe_final = df.drop(df.columns,axis = 1)
            
            for col in df.columns:
                nome = "fx_" + col
                d1 = pd.DataFrame({nome : pd.cut(df[col], np.unique(tab_bins[col]), include_lowest = False)})
                d1[nome] = d1[nome].astype("category")
                dataframe_final = pd.concat([dataframe_final, d1] , axis = 1)
            
            return dataframe_final

        tab_bins = cut_n(base_ref.drop([safra], axis = 1), quantidade)
        tabela = pd.concat([base_ref,base_oot],axis = 0, sort = False)
        dados_cat = apply_cut(tabela.drop([safra], axis = 1), tab_bins)

        dados_cat = pd.concat([dados_cat, tabela[safra].astype(str)],axis = 1)
        dados_cat['value'] = 1
        tabela['value'] = 1
        dados_cat[safra] = dados_cat[safra].str[:10]
        dados_cat[safra] = dados_cat[safra].astype("category")

        for f in dados_cat.columns.values:
            if dados_cat[f].nunique() > 1:
                if ((f != 'value') & (f != safra)):
                    nome = f + '.png'
                    dados_cat[f] = dados_cat[f].astype("category")

                    fig = pd.pivot_table(dados_cat, index = [safra], values = ["value"], columns = [f], aggfunc = np.sum)\
                            .apply(lambda x: x*100/sum(x), axis = 1)\
                            .plot(kind = "bar", stacked = True, figsize = (10,5),
                                  colormap = ListedColormap(sns.color_palette("husl", quantidade)))

                    plt.legend(loc = 'center left', bbox_to_anchor = (1, .5), ncol = 1, fontsize = 8, title_fontsize = 10)
                    plt.title(f,fontdict = {'fontsize' : 12})
                    plt.xlabel("Safras", fontsize = 12) 
                    plt.ylabel("Percentage (%)", fontsize = 12)
                    plt.show();
            else:
                if ((f != 'value') & (f != safra)):
                    nome = f.replace('fx_', '') + '.png'
                    f_ajust = f.replace('fx_', '')
                    tabela[f_ajust] = tabela[f_ajust].astype("category")

                    fig = pd.pivot_table(tabela, index = [safra], values = ["value"], columns = [f_ajust], aggfunc = np.sum)\
                            .apply(lambda x: x*100/sum(x), axis = 1)\
                            .plot(kind = "bar", stacked = True, figsize = (10,5),
                                  colormap = ListedColormap(sns.color_palette("husl", quantidade)))

                    plt.legend(loc = 'center left', bbox_to_anchor = (1, .5), ncol = 1, fontsize = 8, title_fontsize = 10)
                    plt.title(f.replace('fx_', ''), fontdict = {'fontsize' : 12})
                    plt.xlabel("Safras", fontsize = 12) 
                    plt.ylabel("Percentage (%)", fontsize = 12)
                    plt.show();                
        
    
    def quebras_dev(self, dataframe, quantidade):
        bins = []
        df = dataframe.select_dtypes('number')
        for col in df.columns:
            if self.se_dummy(df,col):
                bins_aux = [df[col].unique()[0],df[col].unique()[1]] * (5)
                bins_aux.sort()
                bins.append(bins_aux)
            else: 
                bins_aux = algos.quantile(df[col], np.linspace(0, 1, quantidade))
                bins.append(bins_aux)
        
        return pd.DataFrame(bins, index = df.columns).T

    ##################################################################
    ##################################################################
    #  ALGUMA FUNÇOES AUXILIARES
    ##################################################################
    ##################################################################
    
    # SALVAR OBJETOS
    def save_model_pkl(self, nome_do_modelo = "modelo_teste", objeto = ""):
        filename = nome_do_modelo+'.pkl'
        pickle.dump(objeto, open(filename, 'wb'))
    
    # EVOLUCAO DO PROCESSO EM FOR 
    def progresso_barra(self, value, value_min = 1, value_max = 100, step = 1):
        return widgets.IntProgress(value = value, 
                                   min = value_min, 
                                   max = value_max, 
                                   step = step,
                                   description = 'Processo: ',
                                   bar_style = 'success', # 'success', 'info', 'warning', 'danger' or ''
                                   orientation = 'horizontal')
    
    #BACKUP
    def include(self, nome_arquivo, pasta_arquivo):
        dir_orig = os.getcwd()
        os.chdir(pasta_arquivo)
        if os.path.exists(nome_arquivo):
            exec(compile(source = open(nome_arquivo).read(), filename = nome_arquivo, mode = 'exec'),globals())    
        else:
            print('ERRO - ARQUIVO NAO EXISTE')
        os.chdir(dir_orig)  
        
    def getdata_dolphin(self, input_dir, hdfs_path_input, name_df = "dados", delimiter = ";"):

        print('LEMBRETE: KINIT no terminal!')
        command = 'hadoop fs -text ' + hdfs_path_input + '/*' + ' >> ' + input_dir + '/'+name_df+'.csv'
        subprocess.Popen(command, shell = True, stdout = subprocess.PIPE).communicate()
        output_file = pd.read_csv(input_dir + '/'+name_df+'.csv', sep = delimiter, header = None) 
        print('darwin_getdata_dolphin executada!')
        return output_file
        
    def layout_dolphin(self, dados,dict_colnames,list_index):
        dados = dados.rename(columns = dict_colnames)
        dados = dados.set_index(list_index)
        print('darwin_layout executada!')
        return dados

    def lightgbm_proccess_fast(self,x_train,y_train,x_test,y_test):
        """
        Função para execução de modelos de forma pré-definida. Utilizada dentro da função get_feature_selection.

        Args:

            x_train (pandas.DataFrame): dados de input de treinamento
            y_train (pandas.DataFrame): dados de Target de treinamento
            x_test (pandas.DataFrame): dados de input de teste
            y_test (pandas.DataFrame): dados de Target de teste

        Returns:
            ligthGBM_Skl(LGBMClassifier): modelo resultante do treinamento


        """
        param_grid = {
        'max_depth': 7,
        'num_leaves': 8,
        'reg_alpha': 0.1,
        'reg_lambda': 0.9,
        'n_estimators': 500,
        'learning_rate': 0.01
        }

        early_stopping = 10
        seed = 19910912
        is_unbalance = False
        scale_pos_weight = None
        
        ligthGBM_Skl = lgb.LGBMClassifier(boosting_type = 'gbdt',
                                    objective = 'binary', 
                                    metric = 'auc',
                                    is_unbalance = False,
                                    scale_pos_weight = None,
                                    early_stopping_rounds = 10,
                                    max_depth = param_grid['max_depth'],
                                    num_leaves = param_grid['num_leaves'],
                                    reg_alpha = param_grid['reg_alpha'],
                                    reg_lambda = param_grid['reg_lambda'],
                                    n_estimators = param_grid['n_estimators'],
                                    verbose = -1,
                                    learning_rate = param_grid['learning_rate'],
                                    random_state = 19910912)

        ligthGBM_Skl.fit(x_train, y_train,
                        eval_metric = 'auc',
                        eval_set = [(x_train, y_train),(x_test, y_test)])
        
        
        return ligthGBM_Skl

    def get_sample_data(self, query, data_version, fs, params, sample_shr): #0.-1
        """
        Função para definição de uma amostra

        Args:

            query (string): Query do público alvo
            data_version (string): Safra para treinamento no formato yyyy-mm-dd
            fs (FeatureStore): objeto da classe FeatureStore
            params (dict): Dicionário contendo os parâmetros do project.yaml do modelo
            sample_shr(float): valor decimal representando a porcentagem de amostras que deseja armazenar

        Returns:
            base_selection(string): Nome da tabela contendo a amostra do público alvo
            
        """
        
        import math
        data = fs.fs_crud.read(query = query, to_dataframe = True)
        
        data_month = data[data['data_version'].astype('str')==data_version]
        
        data_month = data_month.drop_duplicates([params['dataset']['id_column']])
        
        sample_len = int(math.floor(data_month.shape[0]*sample_shr))
        
        sample = data_month.sample(n= sample_len)
        
    #     if data_month.shape[0] > 200000:
    #         sample = data_month.sample(n = 200000)
    #     else:
    #         sample = data_month
            
        colunas_publico = []
        #Ajuste Guilherme 2023-12-07
        if len(params.get('key_selection',[]))>0:
            colunas_publico = params['key_selection'].copy()
            
        colunas_publico.append('data_version')
        colunas_publico.append(params['dataset']['label_column'])    
        
        try:
            fs.save_model_basetable(table_name = 'variable_selection'
                                    , df = sample[colunas_publico], overwrite = True)
            
    #         fs.save_model_basetable(table_name = 'variable_selection'
    #                                 , df = sample[[params['key_selection']
    #                                                ,'data_version','TARGET']], overwrite=True)
        except:
            fs.save_model_basetable(table_name = 'variable_selection'
                                    , df = sample[colunas_publico])
    #         fs.save_model_basetable(table_name = 'variable_selection'
    #                                 , df = sample[[params['key_selection']
    #                                                 ,'data_version','TARGET']])
            
        base_selection = f'{fs.gcp_project_db}.{fs.mlops}.tb_variable_selection'
        
        return base_selection    
        
    
        
    def get_feature_selection(self,params, public_query, data_version, sample_shr=1 ,nao_books = [], reprocessar =[], overwrite = False):
        """
        Função para seleção de features de acordo com os Books e pre-books existentes no dataset FeatureStore_Books e dataset Refined.

        Args:

            params (dict): Dicionário contendo os parâmetros do project.yaml do modelo
            public_query (string): Query do público alvo
            data_version (string): Safra para treinamento no formato yyyy-mm-dd
            sample_shr(float): valor decimal representando a porcentagem de amostras que deseja armazenar. Valor padrão 1 (100%)
            nao_books(list<String>): Lista de Strings de books que deseja evitar na seleção. Valor padrão []
            reprocessar(list<String>): Lista de Strings de books que deseja executar novamente. Valor padrão []
            overwrite(Bool): Deleta os arquivos features.json e relations.json começando o processo de seleção do começo.

        Returns:
            features.json (file): Arquivo contendo em formato json com todas as features selecionadas para cada book e pré-book utilizadas na função da FeatureStore load_dataset_data
            relations.json (file): Arquivo contendo em formato json com todas as queries de left join utilizadas na função da FeatureStore load_dataset_data     
        """
        
        print('###################################################')
        print('####### PROCESSO FEATURE SELECTION INICIADO #######')
        print('###################################################')
        
        from featurestore.featurestore import FeatureStore
        import yaml
        import lightgbm as lgb 
        from datetime import datetime
        import json
        from sklearn.model_selection import train_test_split
        from feature_engine.encoding import WoEEncoder
        from sklearn.pipeline import Pipeline
        import os

        # try: 
        #     with open('./code/src/base_query.sql','r') as file: 
        #     #with open('./base_query.sql','r') as file:
        #         sql_query = file.read()
        # except:
        #     with open('home/jupyter/code/src/base_query.sql','r') as file:
        #     #with open('home/jupyter/code/src/base_query.sql','r') as file:
        #         sql_query = file.read()
        
        fs = FeatureStore(app_project = params['app_project'], **params['feature_store'])

        base_selection = self.get_sample_data(query = public_query, data_version = data_version, fs = fs, params = params, sample_shr = sample_shr)
        
        
        if os.path.isfile("./features.json") and os.path.isfile("./relations.json") and overwrite == False:
            with open ('./features.json','r') as file:
                features_per_book = json.load(file)
            with open ('./relations.json','r') as file:
                relations = json.load(file)
            new_file = False
            alias = len(list(features_per_book.keys())) + 1
        else:
            features_per_book = {}
            relations = {}
            new_file = True
            alias = 1
            
        chaves = params['key_selection']
        
        n_colunas = '","'.join(chaves)
        
        # sql_bks = f'''
        # SELECT 
        #     name 
        # FROM `csf-core-data-prd.FeatureStore_Books.tb_fs_FeatureSets` 
        # WHERE entity in (
        #                 SELECT id 
        #                 FROM `csf-core-data-prd.FeatureStore_Books.tb_fs_Entities` 
        #                 WHERE id_column in ("{n_colunas}")
        #                 )
        # '''
        
        threshold = params['f_importance_threshold']
        
        

        for chave in chaves:

            sql_bks = f'''
            SELECT 
                name 
            from `csf-core-data-prd.FeatureStore_Books.tb_fs_FeatureSets` 
            where entity in (
                            Select id 
                            from `csf-core-data-prd.FeatureStore_Books.tb_fs_Entities` 
                            where id_column ="{chave}")
            '''
            books = fs.fs_crud.read(query = sql_bks)
        
            tabela_books = [f"csf-core-data-prd.FeatureStore_Books.tb_fs_{book['name']}" for book in books]
        
            for tabela in tabela_books:
                
                # Removendo os books old pois o time de modelagem não quer testar essas informação (aprov: Guilherme Maia)
                if '_old' in tabela and 'bacen_old' not in tabela:
                    continue
                    
                if tabela in list(features_per_book.keys()) and tabela not in reprocessar:
                    continue
                
                if tabela in nao_books:
                    #alias+=1    
                    print(f'* Book não selecionado - {tabela}')
                    continue
                    
                    
                if new_file == False:
                    with open('./features.json', 'r') as file:
                        features_per_book = json.load(file)
                    with open('./relations.json', 'r') as file:
                        relations = json.load(file)
                        
                
                threshold = params['f_importance_threshold']
                colunas = fs.fs_crud.get_table_columns(tabela)
                nao_features = ['id',chave,'version','data_version','timestamp', *n_colunas]
                
                # quando mudar os books base_id virará chave atentar as datas caso o data_version seja diferente

                    
                if chave in ('NUM_NUMBERX','NUM_SERNO'):
                    relations[tabela] = {'relation':f'cast(a{alias}.{chave} as int64) = cast(a0.{chave} as int64) and a{alias}.data_version = a0.data_version'}
                else:
                    relations[tabela] = {'relation':f'a{alias}.{chave} = cast(a0.{chave} as string) and a{alias}.data_version = a0.data_version'}


                if 'tb_fs_bacen' in tabela:     
                    relations[tabela]['relation'] = f'''a{alias}.{chave} = a0.{chave} and 
    cast(a{alias}.data_version as date) between date_add(cast(a0.data_version as date), interval -3 month) and date_add(cast(a0.data_version as date), interval -1 month)'''
                    
                    relations[tabela]['qualify'] = f'ROW_NUMBER() OVER (PARTITION BY a0.{params["dataset"]["id_column"]},a0.data_version ORDER BY a{alias}.data_version DESC) = 1'

                features_per_book[tabela] = []
                for feature in nao_features:
                    if feature in colunas:
                        colunas.remove(feature)

                parametro_inferior = 0
                parametro_superior = 100

                while parametro_inferior < len(colunas):

                    print(f'Book: {tabela} - Treinando colunas {parametro_inferior} a {parametro_superior} de {len(colunas)} disponíveis.')
                    colunas_100 = colunas[parametro_inferior:parametro_superior]
                    colunas_100 = ',b.'.join(colunas_100)
                    colunas_100 = f'b.{colunas_100}'

                    if len(features_per_book[tabela]) > 0:
                        features_boas = ',b.'.join(features_per_book[tabela])
                        features_boas = f'b.{features_boas},'

                    else:
                        features_boas = ''

                    #new meninas
                    if 'tb_fs_bacen' in tabela: 
                        sql = f'''
                                select {colunas_100}
                                    , {features_boas} a.{chave}
                                    , a.{params['dataset']['label_column']} 
                                from {base_selection} a 
                                left join {tabela} b 
                                on b.{chave} = a.{chave} and cast(b.data_version as date) between date_add(cast(a.data_version as date), interval -3 month) and date_add(cast(a.data_version as date), interval -1 month)
                                qualify ROW_NUMBER() OVER (PARTITION BY a.{params["dataset"]["id_column"]},a.data_version ORDER BY b.data_version DESC) = 1
                            '''

                    elif chave in ('NUM_NUMBERX','NUM_SERNO'):
                        sql = f'''
                                select {colunas_100}
                                    , {features_boas} a.{chave}
                                    , a.{params['dataset']['label_column']} 
                                from {base_selection} a 
                                left join {tabela} b 
                                on cast(a.{chave} as int64) = cast(b.{chave} as int64) 
                                    and a.data_version = b.data_version 
                            '''
                    else:
                        sql = f'''
                                select {colunas_100}
                                    , {features_boas} a.{chave}
                                    , a.{params['dataset']['label_column']} 
                                from {base_selection} a 
                                left join {tabela} b 
                                on cast(a.{chave} as string) = b.{chave} 
                                    and a.data_version = b.data_version 
                            '''
        
                    resultado = fs.fs_crud.read(query = sql, to_dataframe = True)

                    #Y = resultado[[params['dataset']['id_column'],params['dataset']['label_column']]].set_index(params['dataset']['id_column'])
                    Y = resultado[[chave, params['dataset']['label_column']]].set_index(chave)

                    Y['TARGET'] = Y['TARGET'].astype('int')

                    #X = resultado.drop(columns=[params['dataset']['label_column']]).set_index(params['dataset']['id_column'])
                    X = resultado.drop(columns=[params['dataset']['label_column']]).set_index(chave)

                    x_train,x_test, y_train,y_test = train_test_split(X,Y, train_size=params['dataset']['train_proportion'])

                    results = self.lightgbm_proccess_fast(x_train,y_train, x_test ,y_test)

                    features_importantes = []
                    for i in range(len(results.feature_importances_)):
                        if results.feature_importances_[i] > threshold:
                            features_importantes.append(results.feature_name_[i])

                    features_per_book[tabela] = features_importantes

                    parametro_inferior = parametro_superior
                    parametro_superior += 100
                    
                    print(features_per_book)
                    
                
                json_object = json.dumps(features_per_book, indent=4)
                with open ('./features.json','w') as file:
                    file.write(json_object)
                    
                if tabela not in reprocessar:
                    relations_object = json.dumps(relations, indent=4)
                    with open ('./relations.json','w') as file:
                        file.write(relations_object)
                    alias+=1
                        
                if new_file == True:
                    new_file = False
                        

        
        tabela_pbks = []

        if 'NUM_NUMBERX' in chaves:
            tab = 'csf-core-data-prd.refined.TB_PBK_PROBE'
            tabela_pbks.append(tab)
            
        if 'NUM_SERNO' in chaves:
            tab = 'csf-core-data-prd.refined.TB_PBK_CROSS_CANAIS'
            tabela_pbks.append(tab)
            
        for tabela in tabela_pbks:
            
            if tabela in list(features_per_book.keys()) and tabela not in reprocessar:
                continue
            
            if tabela in nao_books:
                #alias+=1    
                print(f'* Pre-Book não selecionado - {tabela}')
                continue
                
            if new_file == False:
                with open('./features.json', 'r') as file:
                    features_per_book = json.load(file)
                with open('./relations.json', 'r') as file:
                    relations = json.load(file)

            
            if 'csf-core-data-prd.refined.TB_PBK_PROBE' in tabela:
            
                relations[tabela] = {'relation': f'cast(a{alias}.NUM_ACCOUNT as int64) = cast(a0.NUM_NUMBERX as int64) and a{alias}.DAT_REFERENCIA between cast(a0.data_version as date) and last_day(cast(a0.data_version as date))'}
                relations[tabela]['qualify'] = f'ROW_NUMBER() OVER (PARTITION BY a0.{params["dataset"]["id_column"]},a0.data_version ORDER BY a{alias}.DAT_REFERENCIA DESC) = 1'
                
            
            if 'csf-core-data-prd.refined.TB_PBK_CROSS_CANAIS' in tabela:          
                relations[tabela] = {'relation':f'a{alias}.ID_SERNO = cast(a0.NUM_SERNO as numeric) and a{alias}.DAT_REFERENCIA = cast(a0.data_version as date)'}


            threshold = params['f_importance_threshold']
            colunas = fs.fs_crud.get_table_columns(tabela)
            nao_features = [#PROBE
                            'NUM_DATA_REF','DAT_REFERENCIA','ID_CUSTOMER','COD_POSICAO','DAT_PROC_STAGE'
                            ,'NUM_ACCOUNT','COD_BUS_CONSUMER_IND','COD_ZIP_CODE', 'COD_CURR_STATUS'
                            ,'FLG_ATIVO','FLG_EVENT_COLLECTIONS','FLG_EVENT_CYCLE_POINT',
                            
                            # cross canais
                            'ID_SERNO','NUM_CONTA', 'DAT_REFERENCIA','NME_EMPRESA'
                            ,'NUM_CELULAR', 'TMP_INGESTION','DAT_PROCESSAMENTO'
                            ,"FLG_CONTA_ATIVADA_MES","FLG_CONTA_ATIVA","FLG_ACESS_APP_CRF"
                            ,"FLG_ACESS_SITE_CRF","FLG_ACESS_APP_ATC","FLG_ACESS_SITE_ATC","FLG_CELULAR_SEGURO"
                            ,"FLG_ACESS_WHATSAPP","FLG_LIGACAO_CENTRAL","FLG_ACESSO_TAS","FLG_ATENDIMENTO_LOJA"
                        ]

            features_per_book[tabela] = []
            for feature in nao_features:
                if feature in colunas:
                    colunas.remove(feature)

            parametro_inferior = 0
            parametro_superior = 100

            while parametro_inferior < len(colunas):

                print(f'Pre Books: {tabela} - Treinando colunas {parametro_inferior} a {parametro_superior} de {len(colunas)} disponíveis.')

                colunas_100 = colunas[parametro_inferior:parametro_superior]
                colunas_100 = ',b.'.join(colunas_100)
                colunas_100 = f'b.{colunas_100}'

                if len(features_per_book[tabela]) > 0:
                    features_boas = ',b.'.join(features_per_book[tabela])
                    features_boas = f'b.{features_boas},'

                else:
                    features_boas = ''

                if tabela == 'csf-core-data-prd.refined.TB_PBK_PROBE':
                    id_base = 'NUM_ACCOUNT'
                    coluna_data = 'DAT_REFERENCIA'
                    
                    # VERSAO 1
    #                 sql = f'''
    #                 select {colunas_100}, {features_boas} a.{params['dataset']['id_column']}, 
    #                 a.{params['dataset']['label_column']} 
    #                 from {base_selection} a left join {tabela} b 
    #                 on a.{params['dataset']['id_column']} = b.{id_base} and b.{coluna_data} between extract(date from a.data_version) and last_day(extract(date from a.data_version)) 
    #             '''
                    
                    # VERSAO 2
    #                 sql = f'''
    #                 select {colunas_100}, {features_boas} a.{params['dataset']['id_column']}, 
    #                 a.{params['dataset']['label_column']} 
    #                 from {base_selection} a 
    #                 left join {tabela} b 
    #                 on a.{params['dataset']['id_column']} = b.{id_base} 
    #                 where b.{coluna_data} between '2023-07-01' and last_day('2023-07-01') 
    #                 QUALIFY ROW_NUMBER() OVER (PARTITION BY b.{id_base} ORDER BY b.{coluna_data} DESC) = 1 
                
    #                 '''

                    sql = f'''
                    select {colunas_100}, {features_boas} a.{params['dataset']['id_column']}, 
                    a.{params['dataset']['label_column']} 
                    from {base_selection} a 
                    left join {tabela} b 
                    on cast(a.NUM_NUMBERX as int64) = cast(b.{id_base} as int64) 
                    where b.{coluna_data} between '{data_version}' and last_day('{data_version}') 
                    QUALIFY ROW_NUMBER() OVER (PARTITION BY b.{id_base} ORDER BY b.{coluna_data} DESC) = 1 
                    '''

                elif tabela == 'csf-core-data-prd.refined.TB_PBK_CROSS_CANAIS':
                        id_base = 'ID_SERNO'
                        coluna_data = 'DAT_REFERENCIA'

                        #VERSAO 1
    #                     sql = f'''
    #                     select {colunas_100}, {features_boas} a.{params['dataset']['id_column']}, 
    #                     a.{params['dataset']['label_column']} 
    #                     from {base_selection} a left join {tabela} b 
    #                     on a.{params['dataset']['id_column']} = b.{id_base} and extract(date from a.data_version) = b.{coluna_data}
    #                 '''
                        
                        #VERSAO 2
    #                     sql = f'''
    #                     select {colunas_100}, {features_boas} a.{params['dataset']['id_column']}, 
    #                     a.{params['dataset']['label_column']} 
    #                     from {base_selection} a 
    #                     left join {tabela} b 
    #                     on a.{params['dataset']['id_column']} = b.{id_base} 
    #                     and extract(date from a.data_version) = b.{coluna_data}
    #                     '''

                        sql = f'''
                        select {colunas_100}, {features_boas} a.{params['dataset']['id_column']}, 
                        a.{params['dataset']['label_column']} 
                        from {base_selection} a 
                        left join {tabela} b 
                        on CAST(A.NUM_SERNO AS NUMERIC) = b.{id_base}  
                        and extract(date from a.data_version) = b.{coluna_data}
                        '''
            
                resultado = fs.fs_crud.read(query = sql, to_dataframe = True)
                
                Y = resultado[[params['dataset']['id_column']
                            ,params['dataset']['label_column']]].set_index(params['dataset']['id_column'])
                #Y = resultado[[chave,params['dataset']['label_column']]].set_index(chave)

                Y['TARGET'] = Y['TARGET'].astype('int')

                X = resultado.drop(columns=[params['dataset']['label_column']]).set_index(params['dataset']['id_column'])
                #X = resultado.drop(columns=[params['dataset']['label_column']]).set_index(chave)
                
                categoricas=[]
                for column in X.columns:
                    if X[column].dtypes == 'Int64' or X[column].dtypes == 'int64':
                        X[column] = X[column].fillna(0)
                        X[column] = X[column].astype('int')
                    elif X[column].dtypes == 'str' or X[column].dtypes == 'object' or X[column].dtypes == 'string':
                        if column.lower() == 'NUM_ZIP_2DIG'.lower():
                            X[column] = X[column].fillna("0").astype('int')                        
                            continue
                        
                        if column.lower() == 'COD_CURR_DELINQUECY_STATUS'.lower():
                            X.loc[ X[column] == 'Curr Delq Status', column] = "0"
                            X[column] = X[column].fillna("0").astype('int')
                            continue
                            
                        X[column] = X[column].fillna('MIS')
                        X[column] = X[column].astype('object')
                        categoricas.append(column)
            
                x_train, x_test, y_train, y_test = train_test_split(X, Y , train_size = params['dataset']['train_proportion'])

                if len(categoricas) > 0:
                    transformacao_variaveis = Pipeline(steps = [
                        ('WoEEncoder', WoEEncoder(variables = categoricas, fill_value = 1))
                    ]).fit(x_train,y_train) 
                
                    x_train = transformacao_variaveis.transform(x_train)
                    x_test = transformacao_variaveis.transform(x_test)
                    
                results = self.lightgbm_proccess_fast(x_train,y_train, x_test, y_test)

                features_importantes = []
                for i in range(len(results.feature_importances_)):
                    if results.feature_importances_[i] > threshold:
                        features_importantes.append(results.feature_name_[i])

                features_per_book[tabela] = features_importantes

                parametro_inferior = parametro_superior
                parametro_superior += 100

            json_object = json.dumps(features_per_book, indent=4)
            with open ('./features.json','w') as file:
                file.write(json_object)

            if tabela not in reprocessar:
                relations_object = json.dumps(relations, indent=4)
                with open ('./relations.json','w') as file:
                    file.write(relations_object)
                alias+=1

            if new_file == True:
                new_file = False
            
                
    #     json_object = json.dumps(features_per_book, indent=4)
    #     with open ('./features.json','w') as file:
    #         file.write(json_object)
            
    #     relations_object = json.dumps(relations, indent=4)
    #     with open ('./relations.json','w') as file:
    #         file.write(relations_object)
            
        print('###################################')
        print('####### PROCESSO FINALIZADO #######')
        print('###################################')





color_csf = {'principal_rbm': '47 92 167', 'principal_hex': '#075DA7',
             'secundaria_rbm': '27 175 230', 'secundaria_hex': '#1BAFE6',
             'neutra_rbm': '127 127 127', 'neutra_hex': '#7F7F7F','vermelho_hex' : '#EC0000'}

color_atc =  {'principal_rbm': '248 99 2', 'principal_hex': '#F86302',
             'secundaria_rbm': '10 124 67', 'secundaria_hex': '#0A7C43',
             'neutra_rbm': '77 77 77', 'neutra_hex': '#4D4D4D', 'vermelho_hex' : '#EC0000'}




