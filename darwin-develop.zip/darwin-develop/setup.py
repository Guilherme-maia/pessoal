from setuptools import find_packages, setup

VERSION = open('VERSION').read()
LONG_DESCRIPTION = open('README.md').read()

with open("requirements.txt", "r") as fp:
    reqs = fp.read().split("\n")

setup(
    name="darwin",
    packages=find_packages(include=["darwin"]),
    version=VERSION,
    description="Ainda não temos",
    long_description="Ainda não temos",
    long_description_content_type="text/markdown",
    author="Banco Carrefour",
    dependency_links=['git+https://__token__:glpat-W5BcWFJPZNysScXM8Fgs@gitlab.com/api/v4/projects/44302510/packages/pypi/simple'],
    install_requires=[
        reqs,
        "featurestore>=3.0.4b0"
        ],
    setup_requires=["pytest_runner"],
    tests_require=["pytest== 7.2.0"],
    tests_suite="tests",
)